--[[
	Constants specific to Bagnon configuration menus
--]]

local CONFIG, Config = ...
Config.displayRowHeight = 105
Config.components = true
Config.skins = true
Config.columns = true
Config.fading = true
