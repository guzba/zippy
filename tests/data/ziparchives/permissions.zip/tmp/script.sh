#!/bin/bash
echo hi
