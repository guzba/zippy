## links
* $nim/nimdoc/tester.nim: tests html validation
* $nim/tests/nimdoc/: tests `runnableExamples` + `nim doc` logic
