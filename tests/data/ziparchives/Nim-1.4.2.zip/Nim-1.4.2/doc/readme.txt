============================
Nim's documenation system
============================

This folder contains Nim's documentation. The documentation
is written in a format called *reStructuredText*, a markup language that reads
like ASCII and can be converted to HTML automatically!
