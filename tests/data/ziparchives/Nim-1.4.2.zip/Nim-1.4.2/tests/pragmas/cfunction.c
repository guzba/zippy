
int cfunction(void) {
  return NUMBER_HERE;
}
