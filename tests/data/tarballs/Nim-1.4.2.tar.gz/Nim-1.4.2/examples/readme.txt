In this directory you can find several examples for how to use the Nim
library.
