namespace namespaced {
enum Enum { A, B, C };
}
